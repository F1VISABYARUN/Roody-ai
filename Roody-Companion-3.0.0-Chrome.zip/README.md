# Roody Companion 3.0.0 — Chrome hackathon demo

This is the NEW Chrome extension, not the desktop app. No Node.js or PowerShell is needed.

INSTALL
1. Extract this ZIP into a NEW folder named Roody-Companion-3.0.0.
2. Open Chrome: chrome://extensions
3. Turn OFF older Roody extensions so their orb does not appear instead.
4. Turn ON Developer mode, click Load unpacked, and select the folder directly containing manifest.json.
5. Confirm the card says Roody Companion — Hackathon Demo, version 3.0.0.
6. Refresh your work webpage and click the NEW Roody toolbar icon.
7. Look for a green star orb and the header Your companion · 3.0.

CONNECT OPENAI
Click the orb's Settings gear. At the top of Settings, paste your OpenAI key and click Save key. Never paste a key into the chat. The key stays in Chrome local extension storage (separate from desktop encrypted storage).

TRY THE DEMO
Choose Grandparent / Developer / Founder and Teach me / Do with me / Do for me. Save a goal, add tasks, and use Try a sample for explicitly labeled fictional data. Model replies use your actual API account. Look at this analyzes a screenshot and the page. Voice opens a Roody-owned window; click Start conversation and approve microphone permission. English and Telugu supported.

LIMITATIONS
Live voice requires OpenAI Realtime access and billing. Voice receives a once-shared text snapshot, not continuous screen access or screenshot images. Goals/tasks are saved locally; voice changes to tasks must be saved using the task board. Do for me prepares drafts/advice; it does not edit files or operate apps. Personal/login/payment pages remain blocked. No external connectors or delegated execution agents are implemented.
