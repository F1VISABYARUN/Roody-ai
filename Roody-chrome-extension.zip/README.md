# Roody Chrome extension

1. Extract this ZIP into a folder you will keep.
2. Open Chrome and visit chrome://extensions.
3. Enable Developer mode.
4. Click Load unpacked and select the folder that directly contains manifest.json.
5. Right-click the Roody toolbar icon, choose Options, and scroll to Brain & your own keys.
6. Paste your key into OpenAI (GPT) API key, click outside the field to save, and choose OpenAI under Preferred brain.
7. Open a normal webpage and click the Roody icon.

No Node.js, npm, or PowerShell is needed for this extension.
This is browser extension version 2.5.0, with text chat and page/screenshot analysis.
Desktop voice, personas, and task-board features are in the separate Electron demo.
To update an existing unpacked extension, replace its files, click Reload on its Chrome extensions card, and refresh your webpage.
